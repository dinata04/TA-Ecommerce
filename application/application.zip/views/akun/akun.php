<!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Akun</h1>

          </div>
          
          <div class="row">
            <!-- Content Column -->
            <div class="col-lg-12 mb-12">

              <!-- Project Card Example -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                </div>
                <div class="card-body">
                 <div class="table-responsive">
                  <table class="table table-bordered datatable" cellspacing="0">
                  <thead style="text-align : center">
                  <tr>
                   <th>NO</th>
                   <th>NAMA LENGKAP</th>
                   <th>E-MAIL</th>
                   <th>FOTO PROFILE</th>
                   <th>USERNAME</th>
                   <th>PASSWORD</th>
                   <th>KELAMIN</th>
                   <th>NOMOR HP</th>
                   <th>KOTA</th>
                   <th>POINT</th>
                   <th>ROLE</th>
                   <th>AKSI</th>
                  </tr>
                  </thead>
                  
                  <tbody style="text-align : center">
                  </tbody>
                  </table>
                 </div>
                </div>
              </div>
            </div>    
          </div>

        </div>
        <!-- /.container-fluid -->